package com.example.employeegraphql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeGraphqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
