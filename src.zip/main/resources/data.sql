INSERT INTO employees (id, name, age, job, language, pay) VALUES
(1, 'John', 35, 'frontend', 'react', 1),
(2, 'Peter', 40, 'frontend', 'python', 1),
(3, 'Sue', 35, 'frontend', 'react', 1),
(9, 'kang', 35, 'frontend', 'python', 500),
(10, 'Jeong', 28, 'frontend', 'react', 500),
(11, '이순신', 35, 'frontend', 'python', 500);
